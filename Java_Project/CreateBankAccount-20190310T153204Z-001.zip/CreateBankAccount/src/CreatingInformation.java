import java.util.Scanner;

/**
 * Created by Ashikur Rahaman on 24-Oct-16.
 */
public class CreatingInformation {
    public static void main(String[] args) {
        Double balance=0.00;
        Scanner scan=new Scanner(System.in);
        System.out.println("                 !!!Welcome to the Banking World!!!                 ");
        System.out.println("");
        System.out.println("Enter A The of The Account Holder:::");
        String name=scan.nextLine();
        System.out.println("Enter The ID Of Account Holder:::");
        int id=scan.nextInt();
        System.out.println("Enter The Balance::: ");
         balance=scan.nextDouble();
       BankAccount B1=new BankAccount(name,id,balance);
        int manu;

        boolean quit=false;
        do{
            System.out.println(" ");
            System.out.println("1.Account Information");
            System.out.println("2.Withdraw Balance");
            System.out.println("3.Deposite Balance");
            System.out.println("4.Exit");

            System.out.println("");
            System.out.println("Please Enter your Choice:::");
            manu=scan.nextInt();
            switch (manu){

                case 1:
                    B1.Display();
                    break;

                case 2:
                    B1.withdraw();

                    break;

                case 3:
                            B1.deposite ();


                    break;

                case 4:
                        quit=true;
                    break;

            }
        }while (!quit);


    }
}
