import java.util.Scanner;

/**
 * Created by Ashikur Rahaman on 24-Oct-16.
 */
public class BankAccount {
    public String name;
    private   int id;
    private   Double balance;
     Double amount;
    Scanner scan=new Scanner (System.in);
    BankAccount (String name,int id,Double balance )
    {
        this.name=name;
        this.id=id;
        this.balance=balance;
    }
    void Display ()
    {
        System.out.println("Name:::"+name);
        System.out.println("ID:::"+id);
        System.out.println("Balance:::"+balance );
    }

    public int withdraw() {

        System.out.println("Current Banalce is:::" +balance );
        System.out.println("");
        System.out.println("Enter The Amount for Withdraw:::");
        amount = scan.nextDouble();
        if (balance< amount )
        {
            System.out.println("No Enough Balance!!!");
            return 1;
        }
        if (amount<0 )
        {
            System.out.println("");
            System.out.println("Withdraw Process Error!!!");
            System.out.println("");
            System.out.println("Please Enter Correct Value!!!");
            return 1;
        }
        else
            balance =balance -amount;

        System.out.println("");
        System.out.println("Withdraw Process Successfully Complete!!!");
        return 0;

    }

    int deposite(){
        System.out.print("Enter The amount to Deposite :::");
        amount = scan.nextDouble() ;

        if (amount < 0) {
            System.out.println(" ");
            System.out.println("Deposite Process Error!!!");
            System.out.println("");
            System.out.println("Please Enter Correct Value!!!");
            return 1;

        }
        else
            balance = balance + amount;
        System.out.println("");
        System.out.println("Deposite Process Successfully Complete!!!");
        return 0;
    }
}
